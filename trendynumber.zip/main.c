/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int num, temp, digit,inc=0;
    printf("Enter the number ");
    scanf("%d",&num);
    temp=num;
    while(num>0)
    {
        digit=num%10;
        num=num/10;
        inc=inc+1;
    }
    if(inc==3)
    {
        digit=temp%10;
        temp=temp/10;
        digit=temp%10;
        if(digit%3==0)
        {
            printf("It is trendy number");
        }
        else
        {
            printf("It is not trendy number");
        }
    }
    else
    {
        printf("It is a invalid number");
    }

    return 0;
}
