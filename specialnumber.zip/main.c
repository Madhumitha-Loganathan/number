#include <stdio.h>

int main()
{
    int number,first, second, sum,mult,ans;
    printf("Enter the number ");
    scanf("%d",&number);
    if((number>=10)&&(number<=99))
    {
        first=number/10;
        second=number%10;
        sum=first+second;
        mult=first*second;
        ans=sum+mult;
        if(ans==number)
        {
            printf("Special Number");
        }
        else
        {
            printf("Not a special number");
        }
    }

    return 0;
}


