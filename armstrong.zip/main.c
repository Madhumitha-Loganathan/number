/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int number,temp, digit,inc=0;
    printf("Enter the number ");
    scanf("%d",&number);
    temp=number;
    while(number>0)
    {
        digit=number%10;
        number=number/10;
        inc=inc+1;
    }
    
    return 0;
}
