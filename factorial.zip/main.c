#include <stdio.h>

int main()
{
    int number, factorial=1,i;
    printf("Enter the number ");
    scanf("%d",&number);
    for(i=1;i<=number;i++)
    {
        factorial=factorial*i;
    }
    printf("%d",factorial);
    return 0;
}
