#include <stdio.h>

int main()
{
    int start, end, i, j,count=0;
    printf("Enter the start number ");
    scanf("%d",&start);
    printf("Enter the end number ");
    scanf("%d",&end);
    for(i=start;i<=end;i++)
    {
        for(j=2;j<i;j++)
        {
            if(i%j==0)
            {
                count++;
                break;
            }
        }
        if((count==0)&&(i!=1))
        {
            printf("%d\n",i);
        }
        count=0;
    }

    return 0;
}
